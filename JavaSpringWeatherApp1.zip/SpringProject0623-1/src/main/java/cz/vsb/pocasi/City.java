package cz.vsb.pocasi;

public enum City {
	OSTRAVA, HELSINKI, ROME, REYKJAVIK, IRAKLIO
}
